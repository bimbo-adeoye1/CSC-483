package com.csc483.assignment1.search;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 tests for ProductSearch and HybridProductStore.
 * Covers normal cases, edge cases (empty array, null input, duplicates).
 */
public class ProductSearchTest {

    private Product[] unsortedProducts;
    private Product[] sortedProducts;
    private HybridProductStore store;

    @BeforeEach
    public void setUp() {
        // Small catalog for predictable testing
        unsortedProducts = new Product[] {
            new Product(50, "Laptop Pro",    "Laptops",      999.99, 10),
            new Product(10, "USB Hub",       "Accessories",   29.99, 50),
            new Product(30, "Wireless Mouse","Accessories",   49.99, 100),
            new Product(20, "Tablet X",      "Tablets",      499.99, 25),
            new Product(40, "Headphones Z",  "Electronics",  149.99, 75),
        };

        // Sorted copy (by ID ascending: 10, 20, 30, 40, 50)
        sortedProducts = new Product[] {
            new Product(10, "USB Hub",       "Accessories",   29.99, 50),
            new Product(20, "Tablet X",      "Tablets",      499.99, 25),
            new Product(30, "Wireless Mouse","Accessories",   49.99, 100),
            new Product(40, "Headphones Z",  "Electronics",  149.99, 75),
            new Product(50, "Laptop Pro",    "Laptops",      999.99, 10),
        };

        store = new HybridProductStore(unsortedProducts);
    }

    // --- Sequential Search Tests ---

    @Test
    public void testSequentialSearch_foundAtStart() {
        Product result = ProductSearch.sequentialSearchById(unsortedProducts, 50);
        assertNotNull(result);
        assertEquals("Laptop Pro", result.getProductName());
    }

    @Test
    public void testSequentialSearch_foundAtEnd() {
        Product result = ProductSearch.sequentialSearchById(unsortedProducts, 40);
        assertNotNull(result);
        assertEquals("Headphones Z", result.getProductName());
    }

    @Test
    public void testSequentialSearch_notFound() {
        Product result = ProductSearch.sequentialSearchById(unsortedProducts, 999);
        assertNull(result);
    }

    @Test
    public void testSequentialSearch_emptyArray() {
        Product result = ProductSearch.sequentialSearchById(new Product[0], 10);
        assertNull(result);
    }

    // --- Binary Search Tests ---

    @Test
    public void testBinarySearch_foundAtMiddle() {
        // Middle element in sorted array is ID 30
        Product result = ProductSearch.binarySearchById(sortedProducts, 30);
        assertNotNull(result);
        assertEquals("Wireless Mouse", result.getProductName());
    }

    @Test
    public void testBinarySearch_foundAtStart() {
        Product result = ProductSearch.binarySearchById(sortedProducts, 10);
        assertNotNull(result);
        assertEquals("USB Hub", result.getProductName());
    }

    @Test
    public void testBinarySearch_foundAtEnd() {
        Product result = ProductSearch.binarySearchById(sortedProducts, 50);
        assertNotNull(result);
        assertEquals("Laptop Pro", result.getProductName());
    }

    @Test
    public void testBinarySearch_notFound() {
        Product result = ProductSearch.binarySearchById(sortedProducts, 999);
        assertNull(result);
    }

    @Test
    public void testBinarySearch_emptyArray() {
        Product result = ProductSearch.binarySearchById(new Product[0], 10);
        assertNull(result);
    }

    // --- Name Search Tests ---

    @Test
    public void testSearchByName_found() {
        Product result = ProductSearch.searchByName(unsortedProducts, "Tablet X");
        assertNotNull(result);
        assertEquals(20, result.getProductId());
    }

    @Test
    public void testSearchByName_caseInsensitive() {
        Product result = ProductSearch.searchByName(unsortedProducts, "laptop pro");
        assertNotNull(result);
        assertEquals(50, result.getProductId());
    }

    @Test
    public void testSearchByName_notFound() {
        Product result = ProductSearch.searchByName(unsortedProducts, "Gaming Chair");
        assertNull(result);
    }

    @Test
    public void testSearchByName_nullInput() {
        Product result = ProductSearch.searchByName(unsortedProducts, null);
        assertNull(result);
    }

    // --- Hybrid Store Tests ---

    @Test
    public void testHybridStore_searchById() {
        Product result = store.searchById(30);
        assertNotNull(result);
        assertEquals("Wireless Mouse", result.getProductName());
    }

    @Test
    public void testHybridStore_searchByName() {
        Product result = store.searchByName("Tablet X");
        assertNotNull(result);
        assertEquals(20, result.getProductId());
    }

    @Test
    public void testHybridStore_addProduct_maintainsSortedOrder() {
        // Insert a product with ID 25 - should land between ID 20 and 30
        Product newProduct = new Product(25, "Smart Watch", "Electronics", 199.99, 30);
        store.addProduct(null, newProduct);

        assertEquals(6, store.getSize());

        // ID search should still find it correctly
        Product found = store.searchById(25);
        assertNotNull(found);
        assertEquals("Smart Watch", found.getProductName());
    }

    @Test
    public void testHybridStore_addProduct_nameIndexUpdated() {
        Product newProduct = new Product(25, "Smart Watch", "Electronics", 199.99, 30);
        store.addProduct(null, newProduct);

        // Name search should also find the newly added product
        Product found = store.searchByName("Smart Watch");
        assertNotNull(found);
        assertEquals(25, found.getProductId());
    }

    @Test
    public void testHybridStore_searchNotFound() {
        assertNull(store.searchById(999));
        assertNull(store.searchByName("Unknown Item"));
    }
}
