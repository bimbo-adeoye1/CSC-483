package com.csc483.assignment1.search;

/**
 * Represents a product in the TechMart online store.
 * Each product has a unique ID used as the primary search key.
 */
public class Product {

    private int productId;
    private String productName;
    private String category;
    private double price;
    private int stockQuantity;

    /**
     * Constructs a new Product with the given attributes.
     */
    public Product(int productId, String productName, String category,
                   double price, int stockQuantity) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.price = price;
        this.stockQuantity = stockQuantity;
    }

    // Getters
    public int getProductId()       { return productId; }
    public String getProductName()  { return productName; }
    public String getCategory()     { return category; }
    public double getPrice()        { return price; }
    public int getStockQuantity()   { return stockQuantity; }

    @Override
    public String toString() {
        return String.format("Product{id=%d, name='%s', category='%s', price=%.2f, stock=%d}",
                productId, productName, category, price, stockQuantity);
    }
}
