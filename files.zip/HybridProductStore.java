package com.csc483.assignment1.search;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

/**
 * HybridProductStore maintains two internal data structures:
 *
 *   1. A sorted Product array  - used by binary search for ID lookups (O(log n))
 *   2. A HashMap keyed by name - used for fast name lookups (O(1) average)
 *
 * When a new product is added, both structures are updated so they stay in sync.
 * Adding a product requires inserting it in the right sorted position (O(n) shift),
 * but name lookups become O(1) instead of O(n).
 *
 * Hybrid approach complexity summary:
 *   Search by ID   : O(log n)  - binary search on sorted array
 *   Search by name : O(1)      - HashMap lookup
 *   Insert         : O(n)      - shifting elements to maintain sorted order
 *                               (acceptable because products are rarely removed/added
 *                                compared to how often they are searched)
 */
public class HybridProductStore {

    // Sorted by productId - supports binary search
    private Product[] sortedById;

    // Maps productName (lowercase) -> Product - supports O(1) name lookup
    private Map<String, Product> nameIndex;

    private int size;

    /**
     * Builds the hybrid store from an existing array of products.
     * The array does not need to be pre-sorted.
     *
     * @param products  Initial product catalog
     */
    public HybridProductStore(Product[] products) {
        size = products.length;

        // Copy and sort the array by ID
        sortedById = products.clone();
        Arrays.sort(sortedById, Comparator.comparingInt(Product::getProductId));

        // Build the name index
        nameIndex = new HashMap<>(size * 2); // Pre-size to reduce rehashing
        for (Product p : products) {
            nameIndex.put(p.getProductName().toLowerCase(), p);
        }
    }

    /**
     * Searches for a product by ID using binary search.
     * Time complexity: O(log n)
     *
     * @param targetId  The product ID to find
     * @return The matching Product, or null if not found
     */
    public Product searchById(int targetId) {
        int low = 0;
        int high = size - 1;

        while (low <= high) {
            int mid   = low + (high - low) / 2;
            int midId = sortedById[mid].getProductId();

            if (midId == targetId) {
                return sortedById[mid];
            } else if (midId < targetId) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null;
    }

    /**
     * Searches for a product by name using the HashMap index.
     * Time complexity: O(1) average
     *
     * @param name  The product name to find (case-insensitive)
     * @return The matching Product, or null if not found
     */
    public Product searchByName(String name) {
        if (name == null) return null;
        return nameIndex.get(name.toLowerCase());
    }

    /**
     * Adds a new product to both internal structures while keeping the
     * sorted array in sorted order (insertion sort style).
     *
     * Time complexity: O(n) due to shifting elements in the sorted array.
     * The HashMap insert is O(1) on average.
     *
     * @param products    Ignored in this implementation - the store manages its own array.
     *                    Kept in the signature to match the assignment specification.
     * @param newProduct  The product to add
     */
    public void addProduct(Product[] products, Product newProduct) {
        // Grow the array by one slot
        Product[] newArray = new Product[size + 1];

        // Find the correct insertion position using binary search
        int insertPos = findInsertPosition(newProduct.getProductId());

        // Copy elements before the insertion point
        System.arraycopy(sortedById, 0, newArray, 0, insertPos);

        // Place the new product
        newArray[insertPos] = newProduct;

        // Copy elements after the insertion point (shifted right by one)
        System.arraycopy(sortedById, insertPos, newArray, insertPos + 1, size - insertPos);

        sortedById = newArray;
        size++;

        // Update the name index - O(1)
        nameIndex.put(newProduct.getProductName().toLowerCase(), newProduct);
    }

    /**
     * Finds the index where a new product ID should be inserted to keep
     * the array sorted. Uses binary search so this step is O(log n).
     */
    private int findInsertPosition(int targetId) {
        int low = 0;
        int high = size - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (sortedById[mid].getProductId() < targetId) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return low; // low is the correct insertion point
    }

    /**
     * Returns the number of products currently in the store.
     */
    public int getSize() {
        return size;
    }
}
