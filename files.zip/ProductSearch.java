package com.csc483.assignment1.search;

/**
 * Provides search methods for the TechMart product catalog.
 * Includes sequential search, binary search by ID, and name search.
 */
public class ProductSearch {

    /**
     * Searches for a product by ID using sequential (linear) search.
     * Time complexity: O(n) in the worst and average case, O(1) in the best case.
     *
     * @param products  Array of products to search through
     * @param targetId  The product ID to find
     * @return The matching Product, or null if not found
     */
    public static Product sequentialSearchById(Product[] products, int targetId) {
        // Check every element from left to right
        for (Product product : products) {
            if (product.getProductId() == targetId) {
                return product;
            }
        }
        return null; // Target was not found
    }

    /**
     * Searches for a product by ID using binary search.
     * The array MUST be sorted in ascending order by productId before calling this.
     * Time complexity: O(log n) in the worst case, O(1) in the best case.
     *
     * @param products  Sorted array of products (sorted by productId ascending)
     * @param targetId  The product ID to find
     * @return The matching Product, or null if not found
     */
    public static Product binarySearchById(Product[] products, int targetId) {
        int low = 0;
        int high = products.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2; // Avoids integer overflow vs (low+high)/2

            int midId = products[mid].getProductId();

            if (midId == targetId) {
                return products[mid]; // Found it
            } else if (midId < targetId) {
                low = mid + 1;  // Target is in the right half
            } else {
                high = mid - 1; // Target is in the left half
            }
        }

        return null; // Target was not found
    }

    /**
     * Searches for a product by name using sequential search.
     * Binary search cannot be used here because names are not sorted.
     * Time complexity: O(n) in all cases.
     *
     * @param products    Array of products to search through
     * @param targetName  The product name to match (case-insensitive)
     * @return The matching Product, or null if not found
     */
    public static Product searchByName(Product[] products, String targetName) {
        if (targetName == null) return null;

        for (Product product : products) {
            // Case-insensitive comparison for better usability
            if (product.getProductName().equalsIgnoreCase(targetName)) {
                return product;
            }
        }
        return null;
    }
}
