package com.csc483.assignment1.search;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Benchmark program that generates 100,000 random products and measures
 * the performance of sequential vs binary search across best, average,
 * and worst cases. Results are printed in a formatted table.
 */
public class SearchBenchmark {

    // Total number of products in the catalog
    private static final int PRODUCT_COUNT = 100_000;

    // Product IDs are drawn from the range [1, MAX_ID]
    private static final int MAX_ID = 200_000;

    // Number of times each test is repeated to get a stable average
    private static final int REPEAT = 5;

    private static final Random random = new Random(42); // Fixed seed for reproducibility

    public static void main(String[] args) {

        // Step 1: Generate the dataset
        Product[] products = generateProducts(PRODUCT_COUNT);

        // Step 2: Sort a copy by ID so binary search has what it needs
        Product[] sortedProducts = products.clone();
        Arrays.sort(sortedProducts, Comparator.comparingInt(Product::getProductId));

        // Step 3: Pick specific IDs for each test scenario
        int bestCaseId   = sortedProducts[0].getProductId();             // First element
        int middleId     = sortedProducts[PRODUCT_COUNT / 2].getProductId(); // Middle element
        int randomId     = sortedProducts[random.nextInt(PRODUCT_COUNT)].getProductId();
        int worstCaseId  = MAX_ID + 1;  // ID that does not exist in the array

        // Print header
        System.out.println("=".repeat(62));
        System.out.println("TECHMART SEARCH PERFORMANCE ANALYSIS (n = 100,000 products)");
        System.out.println("=".repeat(62));

        // Step 4: Run sequential search tests
        System.out.println("\nSEQUENTIAL SEARCH:");
        double seqBest    = measureSequential(products, bestCaseId);
        double seqAverage = measureSequential(products, randomId);
        double seqWorst   = measureSequential(products, worstCaseId);

        System.out.printf("  Best Case  (ID found at position 0)  : %.3f ms%n", seqBest);
        System.out.printf("  Average Case (random ID)             : %.3f ms%n", seqAverage);
        System.out.printf("  Worst Case   (ID not found)          : %.3f ms%n", seqWorst);

        // Step 5: Run binary search tests (array must be sorted)
        System.out.println("\nBINARY SEARCH:");
        double binBest    = measureBinary(sortedProducts, middleId);
        double binAverage = measureBinary(sortedProducts, randomId);
        double binWorst   = measureBinary(sortedProducts, worstCaseId);

        System.out.printf("  Best Case  (ID at middle)            : %.3f ms%n", binBest);
        System.out.printf("  Average Case (random ID)             : %.3f ms%n", binAverage);
        System.out.printf("  Worst Case   (ID not found)          : %.3f ms%n", binWorst);

        // Step 6: Calculate and display the speedup
        double speedup = seqAverage / binAverage;
        System.out.printf("%nPERFORMANCE IMPROVEMENT: Binary search is ~%.0fx faster on average%n", speedup);

        System.out.println("=".repeat(62));
    }

    /**
     * Runs the sequential search REPEAT times and returns the average time in ms.
     */
    private static double measureSequential(Product[] products, int targetId) {
        long total = 0;
        for (int i = 0; i < REPEAT; i++) {
            long start = System.nanoTime();
            ProductSearch.sequentialSearchById(products, targetId);
            total += System.nanoTime() - start;
        }
        return (total / REPEAT) / 1_000_000.0; // Convert nanoseconds to milliseconds
    }

    /**
     * Runs the binary search REPEAT times and returns the average time in ms.
     */
    private static double measureBinary(Product[] products, int targetId) {
        long total = 0;
        for (int i = 0; i < REPEAT; i++) {
            long start = System.nanoTime();
            ProductSearch.binarySearchById(products, targetId);
            total += System.nanoTime() - start;
        }
        return (total / REPEAT) / 1_000_000.0;
    }

    /**
     * Generates an array of products with unique random IDs from [1, MAX_ID].
     * Names follow the pattern "Product_<id>" and categories rotate through
     * a small set so the data looks realistic.
     */
    private static Product[] generateProducts(int count) {
        String[] categories = {"Electronics", "Laptops", "Phones", "Tablets", "Accessories"};
        Set<Integer> usedIds = new HashSet<>();
        Product[] products = new Product[count];

        for (int i = 0; i < count; i++) {
            // Keep generating IDs until we get one that has not been used yet
            int id;
            do {
                id = random.nextInt(MAX_ID) + 1;
            } while (!usedIds.add(id));

            String name     = "Product_" + id;
            String category = categories[i % categories.length];
            double price    = 10.0 + (random.nextDouble() * 990.0); // Price between $10 and $1000
            int    stock    = random.nextInt(500);

            products[i] = new Product(id, name, category, price, stock);
        }

        return products;
    }
}
